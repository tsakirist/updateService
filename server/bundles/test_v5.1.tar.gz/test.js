const express = require('express');
const app = express();

console.log('Hello');
setInterval(()=> {
    console.log("Hello");
}, 6000);

